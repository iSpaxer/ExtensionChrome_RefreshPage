# Особенности работы стрелочных функций
## Разбираем на примерах

## Как пользоваться

```
    npm install
    npm run build
```
или

```
   npm install
   npm run start
```

Видео с объяснением как это все работает здесь:

https://youtu.be/DlQYk3ZvERo


Полезные видео по настройке webpack:

Минимальная конфигурация:

https://youtu.be/unEl3Hezwpw

Настройка горячей перезагрузки:

https://youtu.be/oOpzkF2nU0s

Настройка сборки проекта с подгрузкой файлов css/scss/изображений:

https://youtu.be/3B-NGZmMe-Y

Модульный принцип конфигурации проекта:

https://youtu.be/fnUqyWyG5kk




