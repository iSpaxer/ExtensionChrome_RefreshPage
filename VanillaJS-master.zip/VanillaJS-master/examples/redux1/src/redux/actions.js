export const INIT_STATE = 'INIT_STATE'
export const CHANGE_CELL = 'CHANGE_CELL'
export const CHANGE_ORDER = 'CHANGE_ORDER'