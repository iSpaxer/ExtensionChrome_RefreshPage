# Пример как можно работать с Redux на чистом JavaScript

## Как пользоваться:

 npm install

 npm run start
 


## Полезные ссылки

Самый правильный способ установки node и npm, настоятельно рекомендую устанавливать только так, это спасет Вас от лишних проблем в будущем.

https://youtu.be/gP4OPx2vBoc 

Как настроить сборку проекта с помощью webpack

https://youtu.be/unEl3Hezwpw

Как настроить горячую перезагрузку (hot reloading) с помощью webpack

https://youtu.be/oOpzkF2nU0s 

