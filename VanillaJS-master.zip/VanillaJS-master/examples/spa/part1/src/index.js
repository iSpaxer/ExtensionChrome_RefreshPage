import './styles/main.scss'
import initRouter from './router'

initRouter()


