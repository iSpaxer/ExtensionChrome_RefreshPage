import './styles/main.scss'
import initRouter from './router'
import './components'

initRouter()


