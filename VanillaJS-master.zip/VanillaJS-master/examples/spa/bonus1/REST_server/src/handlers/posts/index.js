const posts = require('./posts');

module.exports = {
    ...posts
};