const comments = require('./comments');

module.exports = {
    ...comments
};