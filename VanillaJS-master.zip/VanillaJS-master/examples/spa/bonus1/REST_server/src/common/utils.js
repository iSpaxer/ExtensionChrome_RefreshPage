const getToken = (request) => {

};

module.exports = {
    
};